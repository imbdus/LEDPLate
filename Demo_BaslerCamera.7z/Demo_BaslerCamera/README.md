# Demo_BaslerCamera
```Basler相机小Demo，能运行，但未完善。有时间的小伙伴可以参与到项目中来……（开发环境：Qt5.6.2vc2013版 basler用的是5.0.11版）```